<?php
include('config.php');

if (isset($_POST['update'])) {
    $ID = intval($_POST['id']); // Ensure ID is an integer
    $NAME = mysqli_real_escape_string($con, $_POST['name']);
    $PRICE = mysqli_real_escape_string($con, $_POST['price']);
    
    // Handle image upload if a file is provided
    if (!empty($_FILES['image']['name'])) {
        $image_location = $_FILES['image']['tmp_name'];
        $image_name = $_FILES['image']['name'];
        $image_up = 'images/' . $image_name;

        // Move the uploaded file to the desired directory
        if (move_uploaded_file($image_location, $image_up)) {
            // Update query with image
            $update = "UPDATE prod SET name='$NAME', price='$PRICE', image='$image_up' WHERE id=$ID";
        } else {
            echo "<script>alert('فشل في رفع الصورة')</script>";
            exit;
        }
    } else {
        // Update query without image
        $update = "UPDATE prod SET name='$NAME', price='$PRICE' WHERE id=$ID";
    }

    // Execute the update query
    if (mysqli_query($con, $update)) {
        echo "<script>alert('تم تحديث المنتج بنجاح')</script>";
    } else {
        echo "<script>alert('فشل تحديث المنتج')</script>";
    }

    // Redirect back to the main page
    header('Location: index.php');
    exit;
}
?>
